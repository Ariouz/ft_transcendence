# https://github.com/psf/requests/blob/main/src/requests/exceptions.py

class RequestException(Exception):
    """Base class for all request exceptions."""
    pass

